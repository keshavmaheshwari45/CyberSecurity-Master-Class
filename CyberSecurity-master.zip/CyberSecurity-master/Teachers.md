### Instructor Teaching this Course

I'm so excited you're using my curriculum to teach cybersecurity!  Please introduce yourself to other teachers using this curriculum.  By entering your contact information, you agree to allow other teachers to reach out to you if they have questions about your implementation/resources/etc.

|First Name|Last Name|District/School|email|
|----|----|----|----|
|Jenna|Garcia|Nextech|jenna@nextech.org|
|Tim|Clegg|Blue River Valley|timothy.clegg@brv.k12.in.us|
|Sue|O'Connell|Duneland/Chesterton High School|soconnell@duneland.k12.in.us|
|Jo|Cox|Yorktown Community Schools|jcox@yorktown.k12.in.us|
|Nick|Zivanovic|Griffith High School|nickz1@gmail.com|
|Alex|McKinstry|FWCS Career Academy|alexander.mckinstry@fwcs.k12.in.us|

