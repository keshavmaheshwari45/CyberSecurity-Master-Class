# General Concepts

## Overview
There are major themes that will re-occur as we go through the course. You should be aware of how these concepts pertain to different aspects of security.


## Purpose


### Objectives
#### Students will be able to:

### Preparation

### Links
- For the Teacher

- For the Students


### Vocabulary

## Teaching Guide
### Getting Started

### Activity

### Wrap-up


### Assessment Questions


### Extended Learning

### Standards Alignment
Indiana CS3S-1.1

## License
[Cyber Security Curriculum](https://github.com/DerekBabb/CyberSecurity) <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-sa/4.0/88x31.png" /></a> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/">Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License</a>.
